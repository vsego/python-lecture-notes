#!/usr/bin/env python3

"""
Prints several minimums and maximums of the seasonal temperatures.
"""

import seasons

# Get data to a list, as to avoid rereading the file several times.
# We can afford this because the file is fairly small.
data = list(seasons.seasonal_data())

# Minimums and maximums:
print("The lowest average winter temperature:  {:+7.3f}C".format(min(data, key=lambda t: t[1])[1]))
print("  This happened in the year {}.".format(min(data, key=lambda t: t[1])[0]))
print("The highest average winter temperature: {:+7.3f}C".format(max(data, key=lambda t: t[1])[1]))
print("  This happened in the year {}.".format(max(data, key=lambda t: t[1])[0]))
print("The lowest average summer temperature:  {:+7.3f}C".format(min(data, key=lambda t: t[3])[3]))
print("  This happened in the year {}.".format(min(data, key=lambda t: t[3])[0]))
print("The highest average summer temperature: {:+7.3f}C".format(max(data, key=lambda t: t[3])[3]))
print("  This happened in the year {}.".format(max(data, key=lambda t: t[3])[0]))
min_annual = min(data, key=lambda t: t[5])
max_annual = max(data, key=lambda t: t[5])
print("The average anual temperature varied between {:+.3f}C in {} to {:+.3f}C in {}.".format(
    min_annual[5], min_annual[0],
    max_annual[5], max_annual[0]
))
