"""
A module defining the common functionality for analyzing
the seasonal temperature data.
"""

import os.path

# This is the directory with the data
data_dir = os.path.join("eu-data")
# Seasons with their identifiers
seasons = { "13": "Winter", "14": "Spring", "15": "Summer", "16": "Autumn" }

def seasonal_data(fname = os.path.join(data_dir, "europe-seasonal.dat")):
    """
    Read the seasonal data from a fixed-width column file with the columns
    `year`,
    `djf` (Winter: December, January, February),
    `mam` (Spring: March, April, May),
    `jja` (Summer: June, July, August),
    `son` (Autumn: September, October, November), and
    `annual` (Annual average).
    
    The return value is an iterator that returns the tuple
    `(year, djf, mam, jja, son, and annual)`
    for each row of data.
    
    It is assumed that the file has no header.
    
    If the file does not exist, a `FileNotFoundError` exception is raised.
    """
    with open(fname) as f:
        for line in f:
            fields = line.strip().split()
            # Extract year, convert it to `int`, join it back with
            # the rest of values converted to `float`, and `yield`
            # them all as a tuple
            # The `try...except` block ensures that the faulty data
            # (for example, a header) is ignored
            if len(fields) == 6:
                try:
                    yield tuple([int(fields[0])] + [float(x) for x in fields[1:]])
                except ValueError:
                    continue

def smooth(L, r):
    """
    Return a new list obtained from a list `L` by smoothing its values
    for a radius `r`. The returned list is shorter than `L` by `2*r`
    elements because the border values are not smoothed.
    """
    tot = 2*r + 1
    return [ sum(L[i-r:i+r+1])/tot for i in range(r, len(L)-r) ]

