#!/usr/bin/env python3

"""
Map the temperatures data for Europe between the years 1500 and 2002.

The year and the season are built-in variables, defined below.

For the seasons identifiers, check the file `"seasons.py"`.
"""

import os.path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors
import matplotlib.image
import pylab
from sys import exit
import seasons

# Data file name
fname = os.path.join("eu-data", "TT_Europe_1500_2002_New.GDX")
# Image file name
iname = os.path.join("images", "europe.png")

# We ommit the input and give year and season directly.
# This can easily be replaced later.
year = 1969
season = 15

# Filtering string, as per the description in the readme file
fltr = "{:04d}{:02d}".format(year, season)

# Grab the data
with open(fname, mode="rt", encoding="utf8") as f:
    for line in f:
        if line[:6] == fltr:
            break
    else:
        print("No data found for {}.".format(fltr))
        exit(1)

# Convert data from strings to float
data = [float(x) for x in line[6:].strip().split()]

# Prepare a plot
fig = plt.figure()
ax = plt.subplot(111)

# Set colour normalization to min and max values
# between -100 and 100 to avoid junk data (for example,
# -999.99 denotes "no data", i.e., the sea).
norm = matplotlib.colors.Normalize(
    vmin=min(fld for fld in data if fld > -100),
    vmax=max(fld for fld in data if fld < +100)
)

# Reshape the data from a list to a 70x130 matrix
data = np.array(data).reshape((70, 130))

# Get the image
img = matplotlib.image.imread(iname)
im_europe = plt.imshow(img)
pylab.hold(True)

# Create the semi-transparent temperature plot
# with the same extent (dimensions) as the image
im_temps = plt.imshow(data,
    interpolation="bicubic",
    norm=norm,
    alpha=0.43,
    extent=(0,img.shape[1],img.shape[0],0)
)

# Add the colorbar
plt.colorbar(shrink=0.85)

# Set the title
plt.title("European temperatures for the {} of {}.".format(
    seasons.seasons[str(season)],
    "'69" if season == 15 and year == 1969 else year
))
ax.set_xticks([])
ax.set_yticks([])

# Display the plot
plt.show()

